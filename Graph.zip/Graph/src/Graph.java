public class Graph {
    Vertex[] arrayOfVertices;
    int indexCounter = 0;
    boolean undirected = true;

    class Node {
        int vertexId;
        Node next;

        public Node(int vertexId, Node next) {
            this.vertexId = vertexId;
            this.next = next;
        }
    }
    class Vertex {
        String name;
        Node adjacent;

        public Vertex(String name, Node adjacent) {
            this.name = name;
            this.adjacent = adjacent;
        }
    }

    public Graph() {
        this(5,"undirected");
    }

    public Graph(int graphSize, String graphType) {

        if(graphType.equals("directed")) {
            this.undirected = false;
        }

        arrayOfVertices = new Vertex[graphSize];
    }

    public void addVertex(String name) {
        arrayOfVertices[indexCounter] = new Vertex(name, null);
        indexCounter++;
    }

    public void addEdge(String sourceVert, String destinationVert) {
        int srcVertIndex = getVertex(sourceVert);
        int destVertIndex = getVertex(destinationVert);

        arrayOfVertices[srcVertIndex].adjacent = new Node(destVertIndex, arrayOfVertices[srcVertIndex].adjacent);
        if(undirected) {
            arrayOfVertices[destVertIndex].adjacent = new Node(srcVertIndex, arrayOfVertices[destVertIndex].adjacent);
        }
    }

    private int getVertex(String vertexName) {
        for(int i = 0; i < arrayOfVertices.length; i++) {
            if(arrayOfVertices[i].name.equals(vertexName)) {
                return i;
            }
        }
        return -1;
    }

    public void print() {
        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < arrayOfVertices.length; i++) {
            if(arrayOfVertices[i] != null) {
                sb.append(arrayOfVertices[i].name);
                Node node = arrayOfVertices[i].adjacent;
                while(node != null) {
                    sb.append("-->" + arrayOfVertices[node.vertexId].name);
                    node = node.next;
                }
                sb.append("\n");
            }
        }
        System.out.println(sb.toString());
    }

    public boolean isAdjacent(String sourceVertexName, String destinationVertexName) {
        //TODO write your code here.
        // determine if destinationVertexName is adjacent to sourceVertexName
        // Your code should check the adjacent relationships of the source vertex, and return true,
        // if the adjacent relationships of the source vertex, contain the destination index.
        // don't forget to change the return statement
        return false;
    }
}
