public class Main {
  public static void main(String[] args) {
    String[] nodes = {
      "Ari",
      "Evelyn",
      "Paaj",
      "Sol"
    };

    Graph e = new Graph(0, "undirected");
    Graph u = new Graph(5, "undirected");
    Graph d = new Graph(5, "directed");

    for (int i = 0; i < nodes.length; i++) {
      u.addVertex(nodes[i]);
      d.addVertex(nodes[i]);
    }

    for (int i = 0; i < nodes.length; i++) {
      u.addEdge(nodes[i], nodes[(i + 1) % nodes.length]);
      d.addEdge(nodes[i], nodes[(i + 1) % nodes.length]);
    }

    System.out.println("== Testing empty graph ==");
    for (int i = 0; i < nodes.length; i++) {
      String a = nodes[i];
      String b = nodes[(i + 1) % nodes.length];
      if (e.isAdjacent(a, b)) {
        System.out.println("** Failure: Empty graph should NOT have "
          + a + "-->" + b + " adjacent");
      }
    }

    System.out.println("== Testing undirected graph ==");
    for (int i = 0; i < nodes.length; i++) {
      String a = nodes[i];
      String b = nodes[(i + 1) % nodes.length];
      if (!u.isAdjacent(a, b) || !u.isAdjacent(b, a)) {
        System.out.println("** Failure: Undirected graph should have "
          + a + "<-->" + b + " adjacent");
      }
    }

    System.out.println("== Testing directed graph ==");
    for (int i = 0; i < nodes.length; i++) {
      String a = nodes[i];
      String b = nodes[(i + 1) % nodes.length];
      if (!d.isAdjacent(a, b)) {
        System.out.println("** Failure: Directed graph should have "
          + a + "-->" + b + " adjacent");
      }
      if (d.isAdjacent(b, a)) {
        System.out.println("** Failure: Directed graph should NOT have "
          + b + "-->" + a + " adjacent");
      }
    }
  }
}
