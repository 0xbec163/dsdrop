public class InsertionSort {
    public static void main(String[] args) {
        DynamicArray<Integer> a = new DynamicArray<Integer>();
        for (int i = 0; i < 6; i++) {
            a.add(11 - i);
            a.add(i);
        }

        System.out.println(a);
        System.out.println("=>");
        InsertionSort.insertionSort(a);
        System.out.println(a);

        for (int i = 0; i < 12; i++) {
            if (a.get(i) != i) {
                System.out.println("** Failure: Expected "
                    + i + " at index " + i + ", not " + a.get(i));
            }
        }
    }

    private static void insertionSort(DynamicArray<Integer> array) {
        // TODO Implement the insertion sort pseudocode.
    }
}
