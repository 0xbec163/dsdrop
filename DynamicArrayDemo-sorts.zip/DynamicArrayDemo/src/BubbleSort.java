import java.util.Random;

public class BubbleSort {

    private static int operations = 0;

    public static void main(String[] args) {
        DynamicArray<Integer> numberArray = new DynamicArray<Integer>();
        Random rando = new Random();

        for(int i = 0; i < 10000; i++) {
            numberArray.add(rando.nextInt(100));
        }

        System.out.println("The unsorted array***");
        System.out.println(numberArray);

        bubbleSort(numberArray);

        System.out.println("The sorted array***");
        System.out.println(numberArray);
        System.out.println("Operations performed: " + operations);
    }

    private static void bubbleSort(DynamicArray<Integer> numArray) {
        int temp;

        for(int i = 0; i < numArray.size(); i++) {
            for(int j = 0; j < numArray.size() - 1; j++) {
                if(numArray.get(j) < numArray.get(j+1)){
                    temp = numArray.get(j);
                    numArray.set(j, numArray.get(j+1));
                    numArray.set(j+1, temp);
                }
                operations++;
            }
        }
    }
}
