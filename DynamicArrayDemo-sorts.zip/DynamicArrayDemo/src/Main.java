import java.util.Random;
import java.util.NoSuchElementException;

public class Main {
    public static void main(String[] args) {
      System.out.println("Run InsertionSort to check your code.");
    }

    public static int max(DynamicArray<Integer> arr) {
        // Implemented previously.
        throw new NoSuchElementException();
    }

    public static int frequency(DynamicArray<Integer> arr, int target) {
        // Implemented previously.
        throw new NoSuchElementException();
    }
}

