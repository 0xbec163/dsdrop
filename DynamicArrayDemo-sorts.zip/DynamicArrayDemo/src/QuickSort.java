import java.util.Random;

public class QuickSort {

    private static int operations = 0;
    public static void main(String[] args) {
        DynamicArray<Integer> numberArray = new DynamicArray<Integer>();
        Random rando = new Random();

        for(int i = 0; i < 10; i++) {
            numberArray.add(rando.nextInt(100));
        }

        System.out.println("The unsorted array***");
        System.out.println(numberArray);

        quickSort(numberArray, 0, numberArray.size() - 1);

        System.out.println("The sorted array***");
        System.out.println(numberArray);
        System.out.println("Operations performed: " + operations);
    }

    private static void quickSort(DynamicArray<Integer> arr, int head, int tail) {

        if(head < tail) { // termination condition
            // dividing up the list, which updates the head and the tail
            int pivotIndex = partition(arr, head, tail);
            // recursion calls
            quickSort(arr, head, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, tail);
        }
    }

    private static int partition(DynamicArray<Integer> arr, int head, int tail) {
        int compareValue = arr.get(tail);
        int swapPoint = head - 1;

        for(int j = head; j <= tail - 1; j++) {
            if(arr.get(j) < compareValue) {
                swapPoint++;
                int swapTemp = arr.get(swapPoint);
                arr.set(swapPoint, arr.get(j));
                arr.set(j, swapTemp);
            }
            operations++;
        }
        int swapTemp = arr.get(swapPoint + 1);
        arr.set(swapPoint + 1, arr.get(tail));
        arr.set(tail, swapTemp);

        operations++;

        return swapPoint + 1;
    }
}
