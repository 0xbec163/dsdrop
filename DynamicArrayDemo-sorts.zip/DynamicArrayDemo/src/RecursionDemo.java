public class RecursionDemo {

    public static void main(String[] args) {
        int number = 10;
        System.out.println("The factorial of " + number + " is: " + factorial(number));
    }

    private static int factorial(int number) {
        if(number != 0) { // termination condition
            return number * factorial(number -1);
        }
        return 1;
    }

}

// call 4 (param = 0): return to line 10 (value = 1) result = 3
// call 3 (param = 1): return to line 10 (value = 1) result = 3
// call 2 (param = 2): return to line 10 (value = 2) result = 6
// call 1 (param = 3): return to line 5