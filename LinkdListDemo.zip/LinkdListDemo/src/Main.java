import java.util.Random;

public class Main {
    public static void main(String[] args) {
        LinkedListDemo<Integer> lInt = new LinkedListDemo<Integer>();
        LinkedListDemo<String> lStr = new LinkedListDemo<String>();

        System.out.println("== Testing empty LLs ==");
        int index = lInt.indexOf(0); 
        if (index != -1) {
          System.out.println("** Failure: Expected index of -1 for empty lInt, not " + index);
        }
        index = lStr.indexOf(""); 
        if (index != -1) {
          System.out.println("** Failure: Expected index of -1 for empty lStr, not " + index);
        }

        if (lInt.contains(0)) {
          System.out.println("** Failure: Expected empty lInt to return false for 0, not true");
        }
        if (lStr.contains("")) {
          System.out.println("** Failure: Expected empty lStr to return false for \"\", not true");
        }

        try {
          lInt.insertAt(-1, 2);
          System.out.println("** Failure: Expected negative index to throw exception for insertAt");
        } catch (IndexOutOfBoundsException e) { /* pass */ }

        try {
          lInt.insertAt(1, 2);
          System.out.println("** Failure: Expected index greater than size to throw exception for insertAt");
        } catch (IndexOutOfBoundsException e) { /* pass */ }


        System.out.println("== Testing insertAt ==");
        int[] ints = { 3, 4, 5 };
        String[] strings = { "Hello,", "world!" };

        for (int i = ints.length - 1; i >= 0; i--) {
          lInt.insertAt(0, ints[i]);
        }
        for (int i = 0; i < strings.length; i++) {
          lStr.insertAt(i, strings[i]);
        }

        for (int i = 0; i < ints.length; i++) {
          if (lInt.get(i) != ints[i]) {
            System.out.println("** Failure: Expected lInt.index "
              + i + " to be " + ints[i] + ", not " + lInt.get(i));
          }
        }

        for (int i = 0; i < strings.length; i++) {
          if (lStr.get(i) != strings[i]) {
            System.out.println("** Failure: Expected lStr.index "
              + i + " to be " + strings[i] + ", not " + lStr.get(i));
          }
        }

        System.out.println("== Testing indexOf ==");
        for (int i = 0; i < ints.length; i++) {
          if (lInt.indexOf(ints[i]) != i) {
            System.out.println("** Failure: Expected lInt.indexOf("
              + ints[i] + ") to be " + i + ", not " + lInt.indexOf(ints[i]));
          }
        }
        if (lInt.indexOf(0) != -1) {
            System.out.println("** Failure: Expected lInt.indexOf(0) to be -1, not " + lInt.indexOf(0));
        }

        for (int i = 0; i < strings.length; i++) {
          if (lStr.indexOf(strings[i]) != i) {
            System.out.println("** Failure: Expected lStr.indexOf("
              + strings[i] + ") to be " + i + ", not " + lStr.indexOf(strings[i]));
          }
        }
        if (lStr.indexOf("howdy!") != -1) {
            System.out.println("** Failure: Expected lStr indexOf(\"howdy!\") to be -1, not " + lInt.indexOf(0));
        }

        System.out.println("== Testing contains ==");
        for (int i = 0; i < ints.length; i++) {
          if (!lInt.contains(ints[i])) {
            System.out.println("** Failure: Expected lInt.contains("
              + ints[i] + ") to be true");
          }
        }
        if (lInt.contains(0)) {
            System.out.println("** Failure: Expected lInt.contains(0) to be false, not true");
        }

        for (int i = 0; i < strings.length; i++) {
          if (!lStr.contains(strings[i])) {
            System.out.println("** Failure: Expected lStr.contains("
              + strings[i] + ") to be true");
          }
        }
        if (lStr.contains("")) {
            System.out.println("** Failure: Expected lStr.contains(\"\") to be false, not true");
        }
    }
}
