import java.util.NoSuchElementException;

public class LinkedListDemo <T> {
    private int size = 0;
    private Node<T> head = null;
    private Node<T> tail = null;

    private class Node <T> {
        T data;
        Node<T> next;

        // constructor for node
        public Node(T data, Node<T> next) {
            this.data = data;
            this.next = next;
        }

        public String toString() {
            return data.toString();
        }
    }

    // clear in java and languages that manage memory
    public void clear1() {
        if(size > 0) {
            head = null;
            tail = null;
            size = 0;
        }
    }

    // clear in languages like c++ which do not auto manage memory
    public void clear2() {
        Node<T> traverser = head;

        while(traverser != null) {
            Node<T> next = traverser.next;

            traverser.data = null;
            traverser.next = null;
            traverser = next;
        }
    }

    public int size() { return size; }

    public boolean isEmpty() {
        return size == 0;
    }

    public void addFirst(T element) {
        if(isEmpty()) {
            head = new Node <T> (element, null);
            tail = head;
        } else {
            Node<T> entry = new Node<T> (element, head);
            head = entry;
        }
        size++;
    }

    public void addLast(T element) {
        if(isEmpty()) {
            head = new Node <T> (element, null);
            tail = head;
        } else {
            Node<T> entry = new Node<T> (element, null);
            tail.next = entry;
            tail = entry;
        }
        size++;
    }

    public void add(T element) {
        addLast(element);
    }

    public T peekLast() {
        if(isEmpty()) {
            return null;
        }
        return tail.data;
    }

    public T peekHead() {
        if(isEmpty()) {
            return null;
        }
        return head.data;
    }

    private Node<T> getNode(int index) {
        if(index >= size) {
            throw new NoSuchElementException();
        }

        if(index == 0) {
            return head;
        } else if(index == size -1) {
            return tail;
        }

        Node<T> traverser = head.next;
        for(int i = 1; i != index; i++) {
            traverser = traverser.next; // iterate through the list
        }

        return traverser;

    }

    public T get(int index) {
        return getNode(index).data;
    }

    public T removeFirst() {
        if(isEmpty()) {
            throw new NoSuchElementException();
        }

        T data = head.data;
        head = head.next;
        size--;

        return data;
    }

    public T removeLast() {
        if(isEmpty()) {
            throw new NoSuchElementException();
        }

        T data = tail.data;

        if(size == 1) {
            tail = null;
            head = null;
        } else {
            tail = getNode(size() - 2);
            tail.next = null;
        }

        size--;
        return data;
    }

    public T removeAt(int index) {
        if( index < 0 || index >= size) {
            throw new IllegalArgumentException();
        }

        Node<T> previousNode = getNode(index - 1);
        Node<T> removeNode = previousNode.next;

        T data = removeNode.data;
        previousNode.next = removeNode.next;
        size--;
        return data;
    }

    public boolean remove(Object obj) {
        if (head == null) return false;

        Node<T> traverser = head.next;
        Node<T> previous = head;

        if(obj.equals(head.data)) {
            removeFirst();
        }

        while(traverser != null) {
            if(obj == null) {
                if (traverser.data == null) {
                    previous.next = traverser.next;
                    size--;
                    return true;
                }
            } else {
                if(obj.equals(traverser.data)) {
                    previous.next = traverser.next;
                    size--;
                    return true;
                }
            }
            traverser = traverser.next;
            previous = previous.next;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("[");
        Node<T> traverser = head;
        if (head != null) {
            sb.append(traverser.data);
            traverser = traverser.next;
            while (traverser != null) {
                sb.append(", ");
                sb.append(traverser.data);
                traverser = traverser.next;
            }
        }
        sb.append("]");

        return sb.toString();
    }

    public int indexOf(T element) {
        // TODO Find the index of the requested element or -1 if it wasn't found.
        return -1;
    }

    public boolean contains(T element) {
        // TODO Return true if the requested element exists in the list or false otherwise.
        return false;
    }

    public void insertAt(int index, T element) {
        // TODO Create a new Node containing the specified element.
        // Insert the new Node into the list at the provided index.
        // Any index less than zero or greater than the list's size
        // should throw an IndexOutOfBoundsException.
        throw new IndexOutOfBoundsException();
    }
}
