import java.util.NoSuchElementException;

public class DoublyLinkedList <T> {

    private int size =0;
    private Node<T> head = null;
    private Node<T> tail = null;

    private class Node <T> {
        T data;
        Node<T> next;
        Node<T> previous;

        // constructor
        public Node(T data, Node<T> next, Node<T> previous) {
            this.data = data;
            this.next = next;
            this.previous = previous;
        }

        public String toString() {
            return data.toString();
        }
    }

    // empty the list, 0(n)
    // useful for languages where you have to manage memory
    // example of a memory leak
    public void clear() {

        head = null;
        tail = null;
        size = 0;
    }

    // Because Java has automatic garbage collection we can do this.
    public void javaClear() {
        if(size > 0) {
            head = null;
            tail = null;
            size = 0;
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public void addFirst(T element) {
        if(isEmpty()) {
            head = new Node<T>(element, null, null);
            tail = head;
        } else {
            Node<T> entry = new Node<T>(element, head, null);
            head.previous = entry; // original head's previous set to the new entry
            head = head.previous;  // point the head variable to the new entry
        }
        size++;
    }

    public void addLast(T element) {
        if(isEmpty()) {
            head = new Node<T>(element, null, null);
            tail = head;
        } else {
            Node<T> entry = new Node<T>(element, null, tail);
            tail.next = entry; // original tail's next is set to point to the new entry
            tail = tail.next;  // tail variable is set to point to the new entry

        }
        size++;
    }

    public void add(T element) {
        addLast(element);
    }


    public T peekFirst() {
        if(isEmpty()) {
            return null;
        }

        return head.data;
    }

    public T peekLast() {
        if(isEmpty()) {
            return null;
        }

        return tail.data;
    }


    private Node<T> getNode(int index) {
        if(index < 0 || index >= size) {
            throw new NoSuchElementException();
        }
        Node<T> traverser;
        if(index < size/2) { // The index is closer to the head, so start there and move forward
            traverser = head; // start at the head
            for(int i = 0; i != index; i++) { // increment forwards
                traverser = traverser.next; // step forward through each element until we hit the right index.
            }
        } else { // the index is closer to the tail, so start there and move backwards
            traverser = tail; // start at the tail
            for(int i = size - 1; i != index; i--) { // increment backwards
                traverser = traverser.previous; // step backward through each element until we hit the right index.
            }
        }
        return traverser;
    }

    public T get(int index) {
        return getNode(index).data;
    }


    public T removeFirst() {
        if(isEmpty()) {
            throw new NoSuchElementException();
        }

        T data = head.data;
        head = head.next;
        size--;

        if(isEmpty()) {
            tail = null; // if the list is empty, set the tail to null as well
        } else {
            head.previous = null; // if the list is not empty, set the previous pointer of the head to null
            // since nothing comes before the head.
        }
        return data;
    }

    public T removeLast() {
        if(isEmpty()) { throw new RuntimeException("Empty List"); }

        T data = tail.data; // grab the data to return, before we remove the element
        tail = tail.previous; // set the tail to be the previous element (2nd to last)

        size--;

        if(isEmpty()) { // now that we've lowered the size, check to see if this was the only element
            head = null; // if the list is empty, make sure the head is set to null as well.
        } else {
            tail.next = null; // if the list is not empty, set the tail's next pointer to null, thus removing all reference to the former tail.
        }
        return data;
    }

    // private indicates this is intended for internal use as a helper or utility function
    // in order for it to be used by outside code, it would have to be public.
    private T remove(Node<T> removeNode) {
        if(removeNode.previous == null) {return removeFirst();} // if the previous is null, this is the head, so remove first.
        if(removeNode.next == null) {return removeLast();} // if the next is null, this is the tail, so remove last.

        // We are going to redirect the previous pointer of the next node and the next pointer of the previous node
        // in order to skip over the current node.
        removeNode.next.previous = removeNode.previous;
        removeNode.previous.next = removeNode.next;

        T data = removeNode.data; // store the data so we can return it at the end.

        // Memory cleanup, not necessary in java
        removeNode.data = null;
        removeNode = removeNode.previous = removeNode.next = null;

        size--;
        return data;
    }

    public boolean remove(Object obj) {
        Node<T> traverser = head;

        // technically our Linked List can have null objects, so allow search for null
        if(obj == null) {
            for(traverser = head; traverser != null; traverser = traverser.next) {
                if (traverser.data == null) {
                    remove(traverser); // use our internal remove helper function
                    return true;
                }
            }
        } else {
            for(traverser = head; traverser != null; traverser = traverser.next) {
                if (obj.equals(traverser.data)) {
                    remove(traverser); // use our internal remove helper function
                    return true;
                }
            }
        }
        return false;
    }

    public T removeAt(int index) {
        if(index < 0 || index >= size) {
            throw new IllegalArgumentException();
        }

        Node<T> traverser;


        if(index < size/2) { // index is closer to head, so start from head and go forward
            traverser = head;// start traversing from the head
            for(int i = 0; i != index; i++) {
                traverser = traverser.next; // step through each element until we hit the right index.
            }
        } else { // index is closer to tail, so start from tail and go backward
            traverser = tail; //start traversing from the tail
            for(int i = size - 1; i != index; i--) {
                traverser = traverser.previous;
            }
        }
        return remove(traverser);
    }



    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("[ ");
        Node<T> traverser = head;
        while(traverser != null) {
            sb.append(traverser.data + ", ");
            traverser = traverser.next;
        }
        sb.append(" ]");
        return sb.toString();
    }
}
