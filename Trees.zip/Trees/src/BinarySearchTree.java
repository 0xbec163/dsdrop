public class BinarySearchTree <T extends Comparable<T>> {

    private int nodeCount = 0;
    Node root = null;

    private class Node {
        T data;
        Node leftChild;
        Node rightChild;

        public Node(T element, Node left, Node right) {
            this.data = element;
            this.leftChild = left;
            this.rightChild = right;
        }
    }

    public int size() {
        return nodeCount;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    private Node digLeft(Node node) {
        Node current = node;
        while(current.leftChild != null) {
            current = current.leftChild;
        }
        return current;
    }

    private Node digRight(Node node) {
        Node current = node;
        while(current.rightChild != null) {
            current = current.rightChild;
        }
        return current;
    }

    // public facing add
    public boolean add(T element) {
        // check to see if the element is duplicate
        if(contains(element)) {
            return false;
        }

        root = add(root, element);
        nodeCount++;
        return true;
    }

    private Node add(Node node, T element) {
        // if node is null, we've reached the end
        // so we create a new node.
        // This node has no children so it is a "leaf" node
        // because of the recursive call the node we create
        // here is going to be assigned into the right child or left child
        // of the last non-null node
        if(node == null) {
            node = new Node(element, null, null);
        } else {

            int compare = element.compareTo(node.data);

            if(compare < 0) {
                node.leftChild = add(node.leftChild, element);
            }

            if(compare > 0) {
                node.rightChild = add(node.rightChild, element);
            }
        }
        return node;
    }

    // public facing remove, recursively call the internal private remove
    public boolean remove(T element) {
        if(contains(element)) {
            root = remove(root, element);
            nodeCount--;
            return true;
        }
        return false;
    }

    // private internal remove. Recursively search for the node and remove it.
    // must also fix any gaps left in the tree by re-attaching the subtree by one
    // of its nodes to the main tree.
    private Node remove(Node node, T element) {
        if(node == null) {
            return null;
        }

        // compare the element to the current node's data
        int compare = element.compareTo(node.data);
        if(compare < 0) {

            // navigate down the left
            node.leftChild = remove(node.leftChild, element);
        } else if(compare > 0) {
            // navigate down the right
            node.rightChild = remove(node.rightChild, element);
        } else {
            // the data is equal, and we've found the node to remove
            // check the current node for children

            if(node.leftChild == null) {
                // there are no left children. So either there are no child nodes
                // or there is a rightChild subtree. In either case we can simply
                // swap the right child node into the place of the current node.
                return node.rightChild;
            } else if( node.rightChild == null) {
                // there are no right child nodes, so either there are no children
                // or there is a left child subtree. In either case, we can simply
                // swap the right node into the place of the current node.
                return node.leftChild;
            } else {
                // there are subtrees on both sides.
                // in order to replace the removed node, and
                // keep the subtree connected to the main tree
                // we can either replace the removed node, with the
                // smallest node from the right subtree,
                // or the largest node from the left subtree.
                Node temp = digLeft(node.rightChild);

                // put the data from the smallest node (temp node) into the current node
                // this effectively swaps the nodes, removing the one we want removed.
                node.data = temp.data;

                // lastly we want to remove the smallest node that we just
                // copied data from.
                node.rightChild = remove(node.rightChild, temp.data);
            }
        }
        return node;
    }

    private void printInOrder(Node node) {
        if( node == null) {
            return;
        }

        printInOrder(node.leftChild);

        System.out.print(node.data + " ");

        printInOrder(node.rightChild);
    }

    public void print() {
        printInOrder(root);
    }

    // external contains
    public boolean contains(T element) {
        return contains(root, element);
    }

    // external height
    public int height() {
        return height(root);
    }

    // internal contains
    private boolean contains(Node node, T element) {
        // TODO write your contains code here
        // the contains method should recursively search the tree comparing the element
        // to the data of the current node
        // if an equal result occurs (the element was found) return a result of true
        // if the current node is null, then the end of the end of the tree has been reached
        // without finding a match, in this case return false
        return false;
    }

    // internal height
    public int height(Node node) {
        // TODO write your code here.
        // Recursively determine the height of the tree. Note that an empty tree
        // should have a height of 0.
        return 0;
    }
}
