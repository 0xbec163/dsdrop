public class Main {
  public static void main(String[] args) {
    BinarySearchTree<String> bst = new BinarySearchTree<String>();

    System.out.println("== Testing BST ==");
    if (bst.height() != 0) {
      System.out.println("** Failure: Expected empty height to be 0, not " + bst.height());
    }

    if (bst.contains("b")) {
      System.out.println("** Failure: Expected empty BST to not contain \"b\"");
    }

    String[] data = {
      "b",
      "a",
      "c",
      "d"
    };

    for (int i = 0; i < data.length; i++) {
      bst.add(data[i]);
    }

    for (int i = 0; i < data.length; i++) {
      if (!bst.contains(data[i])) {
        System.out.println("** Failure: Expected tree to contain \"" + data[i] + "\"");
      }
    }

    if (bst.height() != 3) {
      System.out.println("** Failure: Expected tree height of 3, not " + bst.height());
    }
  }
}
