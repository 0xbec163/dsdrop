public class Queue <T> {

    // FIFO First in First out. - Add at the end, and remove from the beginning.
    // Both actions to be constant time 0(1)

    DoubleLinkedList<T> data = new DoubleLinkedList<>();

    public Queue() { }

    public Queue(T element) {
        enqueue(element);
    }

    public int size() {
        return data.size();
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public T peek() {
        if(isEmpty()) {
            throw new RuntimeException("Queue Empty");
        }

        return data.peekFirst();
    }

    public T dequeue() {
        if(isEmpty()) {
            throw new RuntimeException("Queue Empty");
        }
        return data.removeFirst();
    }

    public void enqueue(T element) {
        data.addLast(element);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < size(); i++) {
            sb.append("[" + data.get(i) + "]");
        }
        return sb.toString();
    }
}
