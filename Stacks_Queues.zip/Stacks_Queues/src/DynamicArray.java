public class DynamicArray <E> {

    private E [] data;
    private int size = 0;
    private int capacity = 0;

    public DynamicArray(int capacity) {
        if(capacity < 0) {
            throw new IllegalArgumentException("Illegal Capacity: " + capacity);
        }

        this.capacity = capacity;
        @SuppressWarnings("unchecked")
        final E[] data = (E[]) new Object[capacity];
        this.data = data;
    }

    public DynamicArray() {
        this(15);
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public E get(int index) {
        boundCheck(index);
        return data[index];
    }

    public void set(int index, E element) {
        boundCheck(index);
        data[index] = element;
    }

    public void clear() {
        for(int i = 0; i < capacity; i++) {
            data[i] = null;
        }
        size = 0;
    }

    public void add(E element) {
        ensureCapacity(1);
        data[size++] = element;

    }

    private void boundCheck(int index) {
        if(index >= size) {
            throw new IndexOutOfBoundsException();
        }
    }

    private void ensureCapacity(int increase) {
        if(size + increase >= capacity) { // checking to see if we have enough space to add another element
            if(capacity == 0) { // check to see if capacity is zero, because we can't multiply by zero.
                capacity = 1;
            } else {
                capacity *= 2; // double the size of the array
            }

            @SuppressWarnings("unchecked")
            E[] newData = (E[]) new Object[capacity]; // create a new array of double size
            for(int i = 0; i < size; i++) {
                newData[i] = data[i]; // copy the data from the old array into the new array
            }

            data = newData;// overwrite the old array with the new bigger array.

        }
    }

    public E removeAt(int index) {
        boundCheck(index);

        E removedData = data[index];

        for(int i = index; i < size; i++) {
            if(i != size - 1) {
                data[i] = data[i+1];
            } else {
                data[i] = null;
            }

        }
        size--;
        return removedData;
    }

    public boolean remove(Object obj) {
        int index = indexOf(obj);
        if(index != -1) {
            removeAt(index);
            return true;
        }
        return false;
    }

    public int indexOf(Object obj) {
        for(int i = 0; i < size; i++) {
            if (data[i].equals(obj)) {
                return i;
            }
        } // end for
        return -1;
    }

    public boolean contains(Object obj) {
        return indexOf(obj) != -1;
    }

    public String toString() {
        if(size == 0) {
            return "[]";
        } else {
            StringBuilder sb = new StringBuilder(size).append("[");
            for(int i = 0; i < size - 1; i++) {
                sb.append(data[i] + ", ");
            }
            return sb.append(data[size-1] + "]").toString();
        }
    }

}
