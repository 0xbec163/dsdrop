public class Main {
    public static void main(String[] args) {
      String[] samples = {
        "",
        "abc",
        "(",
        ")",
        "()",
        ")(",
        "({)}",
        "({})",
        "(a [b {c}])",
        "(a [b { c } ] )"
      };

      boolean[] expected = {
        true,
        true,
        false,
        false,
        true,
        false,
        false,
        true,
        true,
        true
      };

      System.out.println("== Testing checkBrackets ==");
      for (int i = 0; i < samples.length; i++) {
        boolean result = checkBrackets(samples[i]);
        if (result != expected[i]) {
          System.out.println("** Failure: String \"" + samples[i]
            + "\" returned " + result + " instead of expected " + expected[i]);
        }
      }
    }

    public static boolean checkBrackets(String bracketString) {
        //TODO write your stack problem code here
        // remember to change the return statement
        return false;
    }
}
