import java.util.EmptyStackException;

public class Stack <T> {
    // LIFO Last In First Out
    // adding to a stack must be a constant time action 0(1)
    // removing from a stack must also a constant action 0(1)

    LinkedList<T> data = new LinkedList<T>();

    public Stack() { }

    public Stack(T element) {
        push(element);
    }

    public int size() {
        return data.size();
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public void push(T element) {
        data.addFirst(element);
    }

    public T pop() {
        if(isEmpty()) { throw new EmptyStackException(); }

        return data.removeFirst();
    }

    public T peek() {
        if(isEmpty()) { throw new EmptyStackException(); }
        return data.peekHead();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < data.size(); i++) {
            sb.append("[ " + data.get(i) + " ] \n");
        }
        return sb.toString();
    }
}
