import java.util.Arrays;
import java.util.LinkedList;

class Entry<K, V> {
    int hash;
    K key;
    V value;

    public Entry(K key, V value) {
        this.key = key;
        this.value = value;
        this.hash = key.hashCode();
    }

    public boolean equals(Entry<K,V> other) {
        if(hash != other.hash) {
            return false;
        }
        return key.equals(other.key);
    }

    @Override public String toString() {
        return key + " => " + value;
    }
}

public class HashTableSC <K, V> {
    private static final int DEFAULT_CAPACTIY = 10;
    private static final double DEFAULT_LOAD_FACTOR = .75;

    private double maxLoadFactor;
    private int capacity, threshold, size = 0;
    LinkedList<Entry<K,V>>[] buckets;

    public HashTableSC() {
        this(DEFAULT_CAPACTIY, DEFAULT_LOAD_FACTOR);
    }

    public HashTableSC(int capacity) {
        this(capacity, DEFAULT_LOAD_FACTOR);
    }

    public HashTableSC(int capacity, double loadFactor) {
        if(capacity < 0) {
            throw new IllegalArgumentException("Illegal Capacity");
        }

        if(loadFactor <= 0 || Double.isNaN(loadFactor) || Double.isInfinite(loadFactor)) {
            throw new IllegalArgumentException("Illegal Load Capacity");
        }

        this.maxLoadFactor = loadFactor;
        this.capacity = Math.max(DEFAULT_CAPACTIY, capacity);
        threshold = (int)(this.capacity * maxLoadFactor);
        @SuppressWarnings("unchecked")
        final LinkedList<Entry<K,V>>[] buckets = new LinkedList[this.capacity];
        this.buckets = buckets;
    }

    public int size() {return size;}

    public boolean isEmpty() {return size() == 0;}

    public void clear() {
        Arrays.fill(buckets, null);
        size = 0;
    }

    // remainder / division method of hashing
    public int hash(int key) {
        return Math.abs(key % buckets.length);
    }

    public boolean containsKey(K key) {
        int bucketIndex = hash(key.hashCode());
        return findEntry(bucketIndex, key) != null;
    }

    private Entry<K,V> findEntry(int bucketIndex, K key) {
        if(key == null) { return null;}

        LinkedList<Entry<K,V>> bucket = buckets[bucketIndex];
        if(bucket == null) {
            return null;
        }

        for(Entry<K,V> entry : bucket) {
            if(entry.key.equals(key)) {return entry;}
        }
        return null;
    }

    public V put(K key, V value) {
        Entry<K,V> newEntry = new Entry<>(key, value);
        int bucketIndex = hash(newEntry.hash);
        return bucketAddEntry(bucketIndex, newEntry);
    }

    private V bucketAddEntry(int bucketIndex, Entry<K,V> newEntry) {
        // check for an existing Linked List in the location of the index
        LinkedList<Entry<K,V>> bucket = buckets[bucketIndex];

        // check if the linked list is null, meaning nothing is stored there
        // create a new linked list and store it
        if(bucket == null) {
            buckets[bucketIndex] = bucket = new LinkedList<>();
        }

        // check to see if this entry already exists.
        // if not exists, add newEntry
        // if exists, update existingEntry
        Entry<K,V> existingEntry = findEntry(bucketIndex, newEntry.key);
        if(existingEntry == null) {
            bucket.add(newEntry);
            if(++size > threshold) {
                resizeTable();
            }
            return null;
        } else {
            V oldVal = existingEntry.value;
            existingEntry.value = newEntry.value;
            return oldVal;
        }
    }

    private void resizeTable() {
        capacity *= 2;
        threshold = (int)(capacity * maxLoadFactor);

        @SuppressWarnings("unchecked")
        LinkedList<Entry<K,V>> [] newBuckets = new LinkedList[capacity];

        for(int i = 0; i< buckets.length; i++) {
            if(buckets[i] != null) {
                for(Entry<K,V> entry: buckets[i]) {
                    int bucketIndex = hash(entry.hash);
                    LinkedList<Entry<K,V>> bucket = newBuckets[bucketIndex];

                    if(bucket == null) {
                        newBuckets[bucketIndex] = bucket = new LinkedList<>();
                    }
                    bucket.add(entry);
                }
            }
        }
        buckets = newBuckets;
    }

    public V get(K key) {
        if(key == null) {return null; }

        int bucketIndex = hash(key.hashCode());
        Entry<K,V> entry = findEntry(bucketIndex, key);

        if(entry != null) {
            return entry.value;
        }

        return null;
    }

    public V remove(K key) {
        if(key == null) {return null;}
        int bucketIndex = hash(key.hashCode());
        return removeEntry(bucketIndex, key);
    }

    private V removeEntry(int bucketIndex, K key) {
        Entry<K,V> entry = findEntry(bucketIndex, key);

        if(entry != null) {
            LinkedList<Entry<K,V>> bucket = buckets[bucketIndex];
            bucket.remove(entry);
            size--;
            return entry.value;
        } else {
            return null;
        }
    }

    @Override public String toString() {
        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < buckets.length; i++) {
            LinkedList<Entry<K,V>> bucket = buckets[i];

            if(bucket != null) {
                sb.append("Index " + i + ": ");
                for(Entry<K,V> entry : bucket) {
                    sb.append("[K:" + entry.key + " V:" + entry.value +"]");
                }
                sb.append("\n");
            } else {
                sb.append("Index " + i + ": null\n");
            }
        }
        return sb.toString();
    }
}
