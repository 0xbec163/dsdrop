import java.util.Random;

public class Main {
    public static void main(String[] args) {
        HashTableSC<String, Integer> hTable = new HashTableSC<>();
        String[] strings = {
          "",
          "a",
          "Josh",
          "hashing"
          "Miriam"
        };

        System.out.println("== Testing hashMultiplication ==");
        int[] eMult = {
            0,
            26,
            14,
            29,
            13
        };
        for (int i = 0; i < strings.length; i++) {
            if (hashMultiplication(strings[i]) != eMult[i]) {
                System.out.println("** Failure: Expected \""
                  + strings[i] + "\" to hash to " + eMult[i] 
                  + ", not " + hashMultiplication(strings[i]));
            }
        }

        System.out.println("\n== Testing hashMidSquare ==");
        int[] eMid = {
            0,
            40,
            41,
            20,
            23
        };
        for (int i = 0; i < strings.length; i++) {
            if (hashMidSquare(strings[i]) != eMid[i]) {
                System.out.println("** Failure: Expected \""
                  + strings[i] + "\" to hash to " + eMid[i] 
                  + ", not " + hashMidSquare(strings[i]));
            }
        }

    }

    public static int hashMultiplication(String key) {
        int tableSize = 40;
        double A = 0.25436;

        // TODO Write code here to transform the key
        // into a an integer using the multiplication method
        // use the size stored in the variable above.
        return 0;
    }

    public static int hashMidSquare(String key) {
        int tableSize = 100;

        // TODO Write code here to transform the key
        // into a an integer using the mid square method
        // and the size stored in the variable above.
        return 0;
    }
}
