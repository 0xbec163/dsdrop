import java.util.Random;
import java.util.NoSuchElementException;

public class Main {
    public static void main(String[] args) {
        DynamicArray<Integer> empty = new DynamicArray<Integer>();
        DynamicArray<Integer> arr = new DynamicArray<Integer>();
        for (int i = 0; i < 10; i++) {
          arr.add(i);
        }

        System.out.println("== Testing max ==");
        try {
          int nse = max(empty);
          System.out.println("** Failure:\n" + empty);
          System.out.println("Mox should throw a NoSuchElementException, not return " + nse);
        } catch (NoSuchElementException e) { /* pass */ }

        int value = max(arr);
        if (value != 9) {
          System.out.println("** Failure:\n" + arr);
          System.out.println("Max should be 9 but is " + value + " instead.\n");
        }

        arr.set(3, 10);
        value = max(arr);
        if (value != 10) {
          System.out.println("** Failure:\n" + arr);
          System.out.println("Max should be 10 but is " + value + " instead.\n");
        }

        arr.set(0, 11);
        value = max(arr);
        if (value != 11) {
          System.out.println("** Failure:\n" + arr);
          System.out.println("Max should be 11 but is " + value + " instead.\n");
        }

        System.out.println("== Testing frequency ==");
        try {
          int nse = frequency(empty, 1);
          System.out.println("** Failure:\n" + empty);
          System.out.println("Frequency should throw a NoSuchElementException, not return " + nse);
        } catch (NoSuchElementException e) { /* pass */ }

        value = frequency(arr, -1);
        if (value != 0) {
          System.out.println("** Failure:\n" + arr);
          System.out.println("Frequency of -1 should be 0 but is " + value + " instead.\n");
        }

        value = frequency(arr, 2);
        if (value != 1) {
          System.out.println("** Failure:\n" + arr);
          System.out.println("Frequency of 2 should be 1 but is " + value + " instead.\n");
        }

        arr.set(9, 2);
        value = frequency(arr, 2);
        if (value != 2) {
          System.out.println("** Failure:\n" + arr);
          System.out.println("Frequency of 2 should be 2 but is " + value + " instead.\n");
        }

        System.out.println("== Testing insertAt ==");
        DynamicArray<Character> arr2 = new DynamicArray<Character>(0);
        Character[] data = { 'c', 'b', 'a' };

        for (int i = 0; i < data.length; i++) {
          arr2.insertAt(0, data[i]);
        }

        for (int i = 0; i < data.length; i++) {
          if (arr2.get(i) != data[data.length - 1 - i]) {
            System.out.println("** Failure:\n" + arr2);
            System.out.println("Expected element at [" + i + "] to be "
              + data[data.length - 1 - i] + ", not " + arr2.get(i) + "\n");
          }
        }

        if (arr2.size() != data.length) {
          System.out.println("** Failure:\n" + arr2);
          System.out.println("Expected a size of " + data.length + ", not " + arr2.size() + "\n");
        }

        int targetCapacity = (int)Math.pow(2, Math.ceil(Math.log(data.length) / Math.log(2)));
        if (arr2.capacity() != targetCapacity) {
          System.out.println("** Failure:\n" + arr2);
          System.out.println("Expected a capacity of " + targetCapacity + ", not " + arr2.capacity() + ".\n");
        }
    }

    public static int max(DynamicArray<Integer> arr) {
        // TODO Find and return the largest number in the array.
        throw new NoSuchElementException();
    }

    public static int frequency(DynamicArray<Integer> arr, int target) {
        //TODO Find the frequency of the target number in the array.
        throw new NoSuchElementException();
    }
}
