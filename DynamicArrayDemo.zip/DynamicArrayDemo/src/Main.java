import java.util.Random;

public class Main {

    public static void main(String[] args) {
        DynamicArray<Integer> arr = new DynamicArray<Integer>();

        for(int i = 0; i < 20; i++) {
            arr.add(i);
        }

        System.out.println(arr.size());
        System.out.println(arr);
        System.out.println("*****************");

        arr.removeAt(10);

        System.out.println(arr.size());
        System.out.println(arr);
        System.out.println("*****************");

        arr.remove(4);
        System.out.println(arr.size());
        System.out.println(arr);
        System.out.println("*****************");

        arr.set(0, 50);
        System.out.println(arr.size());
        System.out.println(arr);
        System.out.println("Value at Index 0: " + arr.get(0));
        System.out.println("Index of 9: " + arr.indexOf(9));
        System.out.println("Index of 10: " + arr.indexOf(10));
        System.out.println("*****************");


        //TODO Student Assignment
        // Code to call Find the High Number Assignment
        DynamicArray<Integer> highNumberArray = new DynamicArray<Integer>();
        Random randGen = new Random();
        for(int i = 0; i < 14; i++) {
            highNumberArray.add(randGen.nextInt(100));
        }
        System.out.println("*********");
        System.out.println("The largest number in the array is: " + max(highNumberArray));
        System.out.println("");

        // Code to call Find the Frequency of the target number Assignment
        DynamicArray<Integer> frequencyArray = new DynamicArray<Integer>();
        for(int i = 0; i < 30; i++) {
            frequencyArray.add(randGen.nextInt(10));
        }
        System.out.println("The frequency of the number 7 is: " + frequency(frequencyArray, 7));
        System.out.println("*********");

        // Code to call the Insert function Assignment
        DynamicArray<Integer> insertArray = new DynamicArray<Integer>();
        for(int i = 0; i < 10; i++) {
            insertArray.add(randGen.nextInt(10));
        }
        System.out.println(" ");
        System.out.println("The initial Array: " + insertArray);
        System.out.println("Initial Size: " + insertArray.size());
        insertArray.insertAt(5, 15);
        System.out.println(" ");
        System.out.println("The Array after insert: " + insertArray);
        System.out.println("Updated Size: " + insertArray.size());

    }

    public static int max(DynamicArray<Integer> arr) {
        //TODO Find and return the largest number in the array
        return 0; // don't forget to change the return statement to return the largest number
    }

    public static int frequency(DynamicArray<Integer> arr, int target) {
        //TODO find the frequency of the target number in the array
        return 0; // don't forget to change the return statement to return the frequency

    }
}
